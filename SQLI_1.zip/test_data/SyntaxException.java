package com.sqli.framework;

public class SyntaxException extends Exception {

}
