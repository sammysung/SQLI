package com.sqli.framework;

public class Toke{
	public final int tag;
	public Toke(int t){
		tag = t;
	}
}
