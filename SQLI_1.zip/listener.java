package com.sqli.framework;

import org.antlr.v4.runtime.ParserRuleContext;

public class listener extends TestBaseListener {
        String[] taut=new String[30];
        static String[] query=new String[30];
        int t=0;
        static int count=0;
        @Override public void enterEveryRule(ParserRuleContext ctx) {  //see gramBaseListener for allowed functions
            //System.out.println("Test log: " + ctx.getText());      //code that executes per rule
        }
        
        @Override public void enterQuery(TestParser.QueryContext ctx) { 
            //query[count]=ctx.getText();
            //count++;
            //System.out.println("Query found "+(++count)+ ctx.getText());
        }
        
        @Override public void enterTautology(TestParser.TautologyContext ctx) { 
            taut[t]=ctx.getText();
            t++;
            System.out.println("Potentional tautology found! " + ctx.getText());
        }
        
        @Override public void enterCommand(TestParser.CommandContext ctx) { 
            //System.out.println("Here's an emoticon! " + ctx.getText());
        }
        
        @Override public void enterDoublenested(TestParser.DoublenestedContext ctx) { 
            query[count]=ctx.getText();
            count++;
            //System.out.println("double "+ctx.getText());
        }
        
        @Override public void enterLongline(TestParser.LonglineContext ctx) { 
            query[count]=ctx.getText();
            count++;
            //System.out.println("long "+ctx.getText());
        }
        
        @Override public void enterLine(TestParser.LineContext ctx) { 
            query[count]=ctx.getText();
            count++;
            //System.out.println("line "+ctx.getText());
        }
        
        @Override public void enterPiggyback(TestParser.PiggybackContext ctx) { 
            System.out.println("Piggyback found here!  "+ctx.getText());
        }
        
        @Override public void enterStoredprocedure(TestParser.StoredprocedureContext ctx) { 
            System.out.println("Stored procedure found!  "+ctx.getText());
        }
        
        public String[] getTaut(){
            return taut;
        }
        
        public int getTautCount(){
            return t;
        }
        
        public String[] getQuery(){
            return query;
        }
        
        public int getQueryCount(){
            return count;
        }
    } 
