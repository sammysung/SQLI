#!/bin/bash

cd ..
cd ..
mkdir E-unix
cmake . -G "Eclipse CDT4 - Unix Makefiles" -B./E-unix
cd E-unix
make
 
