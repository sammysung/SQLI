#!/bin/bash

sudo apt-get install default-jre cmake
