// Generated from Test.g4 by ANTLR 4.7.2
package com.sqli.framework;

import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link TestParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface TestVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link TestParser#query}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQuery(TestParser.QueryContext ctx);
	/**
	 * Visit a parse tree produced by {@link TestParser#doublenested}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDoublenested(TestParser.DoublenestedContext ctx);
	/**
	 * Visit a parse tree produced by {@link TestParser#longline}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLongline(TestParser.LonglineContext ctx);
	/**
	 * Visit a parse tree produced by {@link TestParser#line}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLine(TestParser.LineContext ctx);
	/**
	 * Visit a parse tree produced by {@link TestParser#linetype}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLinetype(TestParser.LinetypeContext ctx);
	/**
	 * Visit a parse tree produced by {@link TestParser#request}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRequest(TestParser.RequestContext ctx);
	/**
	 * Visit a parse tree produced by {@link TestParser#tautology}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitTautology(TestParser.TautologyContext ctx);
	/**
	 * Visit a parse tree produced by {@link TestParser#command}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCommand(TestParser.CommandContext ctx);
	/**
	 * Visit a parse tree produced by {@link TestParser#operator}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitOperator(TestParser.OperatorContext ctx);
	/**
	 * Visit a parse tree produced by {@link TestParser#quotes}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQuotes(TestParser.QuotesContext ctx);
	/**
	 * Visit a parse tree produced by {@link TestParser#leftparent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLeftparent(TestParser.LeftparentContext ctx);
	/**
	 * Visit a parse tree produced by {@link TestParser#rightparent}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitRightparent(TestParser.RightparentContext ctx);
	/**
	 * Visit a parse tree produced by {@link TestParser#equals}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEquals(TestParser.EqualsContext ctx);
	/**
	 * Visit a parse tree produced by {@link TestParser#endquery}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitEndquery(TestParser.EndqueryContext ctx);
	/**
	 * Visit a parse tree produced by {@link TestParser#digit}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDigit(TestParser.DigitContext ctx);
	/**
	 * Visit a parse tree produced by {@link TestParser#variable}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitVariable(TestParser.VariableContext ctx);
	/**
	 * Visit a parse tree produced by {@link TestParser#quoted}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitQuoted(TestParser.QuotedContext ctx);
}
