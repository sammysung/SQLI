// Generated from Test.g4 by ANTLR 4.7.2
package com.sqli.framework;
import org.antlr.v4.runtime.atn.*;
import org.antlr.v4.runtime.dfa.DFA;
import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.misc.*;
import org.antlr.v4.runtime.tree.*;
import java.util.List;
import java.util.Iterator;
import java.util.ArrayList;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public class TestParser extends Parser {
	static { RuntimeMetaData.checkVersion("4.7.2", RuntimeMetaData.VERSION); }

	protected static final DFA[] _decisionToDFA;
	protected static final PredictionContextCache _sharedContextCache =
		new PredictionContextCache();
	public static final int
		T__0=1, T__1=2, T__2=3, T__3=4, T__4=5, T__5=6, T__6=7, T__7=8, T__8=9, 
		T__9=10, SELECT=11, FROM=12, GROUP=13, WHERE=14, HAVING=15, UNION=16, 
		SHUTDOWN=17, WORD=18, DIGIT=19, WHITESPACE=20, NEWLINE=21;
	public static final int
		RULE_query = 0, RULE_doublenested = 1, RULE_longline = 2, RULE_line = 3, 
		RULE_linetype = 4, RULE_request = 5, RULE_tautology = 6, RULE_piggyback = 7, 
		RULE_storedprocedure = 8, RULE_command = 9, RULE_procedures = 10, RULE_operator = 11, 
		RULE_quotes = 12, RULE_leftparent = 13, RULE_rightparent = 14, RULE_equals = 15, 
		RULE_endquery = 16, RULE_digit = 17, RULE_variable = 18, RULE_quoted = 19;
	private static String[] makeRuleNames() {
		return new String[] {
			"query", "doublenested", "longline", "line", "linetype", "request", "tautology", 
			"piggyback", "storedprocedure", "command", "procedures", "operator", 
			"quotes", "leftparent", "rightparent", "equals", "endquery", "digit", 
			"variable", "quoted"
		};
	}
	public static final String[] ruleNames = makeRuleNames();

	private static String[] makeLiteralNames() {
		return new String[] {
			null, "','", "'-'", "'<'", "'>'", "'*'", "'''", "'('", "')'", "'='", 
			"';'"
		};
	}
	private static final String[] _LITERAL_NAMES = makeLiteralNames();
	private static String[] makeSymbolicNames() {
		return new String[] {
			null, null, null, null, null, null, null, null, null, null, null, "SELECT", 
			"FROM", "GROUP", "WHERE", "HAVING", "UNION", "SHUTDOWN", "WORD", "DIGIT", 
			"WHITESPACE", "NEWLINE"
		};
	}
	private static final String[] _SYMBOLIC_NAMES = makeSymbolicNames();
	public static final Vocabulary VOCABULARY = new VocabularyImpl(_LITERAL_NAMES, _SYMBOLIC_NAMES);

	/**
	 * @deprecated Use {@link #VOCABULARY} instead.
	 */
	@Deprecated
	public static final String[] tokenNames;
	static {
		tokenNames = new String[_SYMBOLIC_NAMES.length];
		for (int i = 0; i < tokenNames.length; i++) {
			tokenNames[i] = VOCABULARY.getLiteralName(i);
			if (tokenNames[i] == null) {
				tokenNames[i] = VOCABULARY.getSymbolicName(i);
			}

			if (tokenNames[i] == null) {
				tokenNames[i] = "<INVALID>";
			}
		}
	}

	@Override
	@Deprecated
	public String[] getTokenNames() {
		return tokenNames;
	}

	@Override

	public Vocabulary getVocabulary() {
		return VOCABULARY;
	}

	@Override
	public String getGrammarFileName() { return "Test.g4"; }

	@Override
	public String[] getRuleNames() { return ruleNames; }

	@Override
	public String getSerializedATN() { return _serializedATN; }

	@Override
	public ATN getATN() { return _ATN; }

	public TestParser(TokenStream input) {
		super(input);
		_interp = new ParserATNSimulator(this,_ATN,_decisionToDFA,_sharedContextCache);
	}
	public static class QueryContext extends ParserRuleContext {
		public TerminalNode EOF() { return getToken(TestParser.EOF, 0); }
		public List<LinetypeContext> linetype() {
			return getRuleContexts(LinetypeContext.class);
		}
		public LinetypeContext linetype(int i) {
			return getRuleContext(LinetypeContext.class,i);
		}
		public QueryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_query; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).enterQuery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).exitQuery(this);
		}
	}

	public final QueryContext query() throws RecognitionException {
		QueryContext _localctx = new QueryContext(_ctx, getState());
		enterRule(_localctx, 0, RULE_query);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(41); 
			_errHandler.sync(this);
			_la = _input.LA(1);
			do {
				{
				{
				setState(40);
				linetype();
				}
				}
				setState(43); 
				_errHandler.sync(this);
				_la = _input.LA(1);
			} while ( (((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << SELECT) | (1L << FROM) | (1L << GROUP) | (1L << WHERE) | (1L << HAVING) | (1L << UNION))) != 0) );
			setState(45);
			match(EOF);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DoublenestedContext extends ParserRuleContext {
		public List<CommandContext> command() {
			return getRuleContexts(CommandContext.class);
		}
		public CommandContext command(int i) {
			return getRuleContext(CommandContext.class,i);
		}
		public List<RequestContext> request() {
			return getRuleContexts(RequestContext.class);
		}
		public RequestContext request(int i) {
			return getRuleContext(RequestContext.class,i);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(TestParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(TestParser.NEWLINE, i);
		}
		public List<EqualsContext> equals() {
			return getRuleContexts(EqualsContext.class);
		}
		public EqualsContext equals(int i) {
			return getRuleContext(EqualsContext.class,i);
		}
		public List<TerminalNode> WHITESPACE() { return getTokens(TestParser.WHITESPACE); }
		public TerminalNode WHITESPACE(int i) {
			return getToken(TestParser.WHITESPACE, i);
		}
		public List<LeftparentContext> leftparent() {
			return getRuleContexts(LeftparentContext.class);
		}
		public LeftparentContext leftparent(int i) {
			return getRuleContext(LeftparentContext.class,i);
		}
		public DoublenestedContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_doublenested; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).enterDoublenested(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).exitDoublenested(this);
		}
	}

	public final DoublenestedContext doublenested() throws RecognitionException {
		DoublenestedContext _localctx = new DoublenestedContext(_ctx, getState());
		enterRule(_localctx, 2, RULE_doublenested);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(47);
			command();
			setState(48);
			request();
			setState(49);
			match(NEWLINE);
			setState(50);
			command();
			setState(51);
			request();
			setState(52);
			match(NEWLINE);
			setState(53);
			command();
			setState(54);
			request();
			setState(55);
			equals();
			setState(56);
			match(WHITESPACE);
			setState(57);
			leftparent();
			setState(58);
			command();
			setState(59);
			request();
			setState(60);
			match(NEWLINE);
			setState(61);
			command();
			setState(62);
			request();
			setState(63);
			match(NEWLINE);
			setState(64);
			command();
			setState(65);
			request();
			setState(66);
			equals();
			setState(67);
			match(WHITESPACE);
			setState(68);
			leftparent();
			setState(69);
			command();
			setState(70);
			request();
			setState(71);
			match(NEWLINE);
			setState(72);
			command();
			setState(73);
			request();
			setState(75);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,1,_ctx) ) {
			case 1:
				{
				setState(74);
				match(NEWLINE);
				}
				break;
			}
			setState(78);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NEWLINE) {
				{
				setState(77);
				match(NEWLINE);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LonglineContext extends ParserRuleContext {
		public List<CommandContext> command() {
			return getRuleContexts(CommandContext.class);
		}
		public CommandContext command(int i) {
			return getRuleContext(CommandContext.class,i);
		}
		public List<RequestContext> request() {
			return getRuleContexts(RequestContext.class);
		}
		public RequestContext request(int i) {
			return getRuleContext(RequestContext.class,i);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(TestParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(TestParser.NEWLINE, i);
		}
		public LonglineContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_longline; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).enterLongline(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).exitLongline(this);
		}
	}

	public final LonglineContext longline() throws RecognitionException {
		LonglineContext _localctx = new LonglineContext(_ctx, getState());
		enterRule(_localctx, 4, RULE_longline);
		int _la;
		try {
			setState(124);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,8,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(80);
				command();
				setState(81);
				request();
				setState(82);
				match(NEWLINE);
				setState(83);
				command();
				setState(84);
				request();
				setState(85);
				match(NEWLINE);
				setState(86);
				command();
				setState(87);
				request();
				setState(88);
				match(NEWLINE);
				setState(89);
				command();
				setState(90);
				request();
				setState(91);
				match(NEWLINE);
				setState(92);
				command();
				setState(93);
				request();
				setState(95);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,3,_ctx) ) {
				case 1:
					{
					setState(94);
					match(NEWLINE);
					}
					break;
				}
				setState(98);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==NEWLINE) {
					{
					setState(97);
					match(NEWLINE);
					}
				}

				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(100);
				command();
				setState(101);
				request();
				setState(102);
				match(NEWLINE);
				setState(103);
				command();
				setState(104);
				request();
				setState(105);
				match(NEWLINE);
				setState(106);
				command();
				setState(107);
				request();
				setState(108);
				match(NEWLINE);
				setState(109);
				command();
				setState(111);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if ((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__1) | (1L << T__2) | (1L << T__3) | (1L << T__4) | (1L << T__5) | (1L << T__6) | (1L << T__7) | (1L << T__9) | (1L << WORD) | (1L << DIGIT) | (1L << WHITESPACE))) != 0)) {
					{
					setState(110);
					request();
					}
				}

				setState(113);
				command();
				setState(114);
				request();
				setState(115);
				match(NEWLINE);
				setState(116);
				command();
				setState(117);
				request();
				setState(119);
				_errHandler.sync(this);
				switch ( getInterpreter().adaptivePredict(_input,6,_ctx) ) {
				case 1:
					{
					setState(118);
					match(NEWLINE);
					}
					break;
				}
				setState(122);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==NEWLINE) {
					{
					setState(121);
					match(NEWLINE);
					}
				}

				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LineContext extends ParserRuleContext {
		public List<CommandContext> command() {
			return getRuleContexts(CommandContext.class);
		}
		public CommandContext command(int i) {
			return getRuleContext(CommandContext.class,i);
		}
		public List<RequestContext> request() {
			return getRuleContexts(RequestContext.class);
		}
		public RequestContext request(int i) {
			return getRuleContext(RequestContext.class,i);
		}
		public List<TerminalNode> NEWLINE() { return getTokens(TestParser.NEWLINE); }
		public TerminalNode NEWLINE(int i) {
			return getToken(TestParser.NEWLINE, i);
		}
		public LineContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_line; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).enterLine(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).exitLine(this);
		}
	}

	public final LineContext line() throws RecognitionException {
		LineContext _localctx = new LineContext(_ctx, getState());
		enterRule(_localctx, 6, RULE_line);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(126);
			command();
			setState(127);
			request();
			setState(128);
			match(NEWLINE);
			setState(129);
			command();
			setState(130);
			request();
			setState(131);
			match(NEWLINE);
			setState(132);
			command();
			setState(133);
			request();
			setState(135);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,9,_ctx) ) {
			case 1:
				{
				setState(134);
				match(NEWLINE);
				}
				break;
			}
			setState(138);
			_errHandler.sync(this);
			_la = _input.LA(1);
			if (_la==NEWLINE) {
				{
				setState(137);
				match(NEWLINE);
				}
			}

			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LinetypeContext extends ParserRuleContext {
		public LineContext line() {
			return getRuleContext(LineContext.class,0);
		}
		public DoublenestedContext doublenested() {
			return getRuleContext(DoublenestedContext.class,0);
		}
		public LonglineContext longline() {
			return getRuleContext(LonglineContext.class,0);
		}
		public LinetypeContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_linetype; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).enterLinetype(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).exitLinetype(this);
		}
	}

	public final LinetypeContext linetype() throws RecognitionException {
		LinetypeContext _localctx = new LinetypeContext(_ctx, getState());
		enterRule(_localctx, 8, RULE_linetype);
		try {
			setState(143);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,11,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				setState(140);
				line();
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				setState(141);
				doublenested();
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				setState(142);
				longline();
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RequestContext extends ParserRuleContext {
		public List<OperatorContext> operator() {
			return getRuleContexts(OperatorContext.class);
		}
		public OperatorContext operator(int i) {
			return getRuleContext(OperatorContext.class,i);
		}
		public List<QuotesContext> quotes() {
			return getRuleContexts(QuotesContext.class);
		}
		public QuotesContext quotes(int i) {
			return getRuleContext(QuotesContext.class,i);
		}
		public List<VariableContext> variable() {
			return getRuleContexts(VariableContext.class);
		}
		public VariableContext variable(int i) {
			return getRuleContext(VariableContext.class,i);
		}
		public List<DigitContext> digit() {
			return getRuleContexts(DigitContext.class);
		}
		public DigitContext digit(int i) {
			return getRuleContext(DigitContext.class,i);
		}
		public List<TautologyContext> tautology() {
			return getRuleContexts(TautologyContext.class);
		}
		public TautologyContext tautology(int i) {
			return getRuleContext(TautologyContext.class,i);
		}
		public List<PiggybackContext> piggyback() {
			return getRuleContexts(PiggybackContext.class);
		}
		public PiggybackContext piggyback(int i) {
			return getRuleContext(PiggybackContext.class,i);
		}
		public List<StoredprocedureContext> storedprocedure() {
			return getRuleContexts(StoredprocedureContext.class);
		}
		public StoredprocedureContext storedprocedure(int i) {
			return getRuleContext(StoredprocedureContext.class,i);
		}
		public List<EndqueryContext> endquery() {
			return getRuleContexts(EndqueryContext.class);
		}
		public EndqueryContext endquery(int i) {
			return getRuleContext(EndqueryContext.class,i);
		}
		public List<LeftparentContext> leftparent() {
			return getRuleContexts(LeftparentContext.class);
		}
		public LeftparentContext leftparent(int i) {
			return getRuleContext(LeftparentContext.class,i);
		}
		public List<RightparentContext> rightparent() {
			return getRuleContexts(RightparentContext.class);
		}
		public RightparentContext rightparent(int i) {
			return getRuleContext(RightparentContext.class,i);
		}
		public List<TerminalNode> WHITESPACE() { return getTokens(TestParser.WHITESPACE); }
		public TerminalNode WHITESPACE(int i) {
			return getToken(TestParser.WHITESPACE, i);
		}
		public RequestContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_request; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).enterRequest(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).exitRequest(this);
		}
	}

	public final RequestContext request() throws RecognitionException {
		RequestContext _localctx = new RequestContext(_ctx, getState());
		enterRule(_localctx, 10, RULE_request);
		try {
			int _alt;
			enterOuterAlt(_localctx, 1);
			{
			setState(156); 
			_errHandler.sync(this);
			_alt = 1;
			do {
				switch (_alt) {
				case 1:
					{
					setState(156);
					_errHandler.sync(this);
					switch ( getInterpreter().adaptivePredict(_input,12,_ctx) ) {
					case 1:
						{
						setState(145);
						operator();
						}
						break;
					case 2:
						{
						setState(146);
						quotes();
						}
						break;
					case 3:
						{
						setState(147);
						variable();
						}
						break;
					case 4:
						{
						setState(148);
						digit();
						}
						break;
					case 5:
						{
						setState(149);
						tautology();
						}
						break;
					case 6:
						{
						setState(150);
						piggyback();
						}
						break;
					case 7:
						{
						setState(151);
						storedprocedure();
						}
						break;
					case 8:
						{
						setState(152);
						endquery();
						}
						break;
					case 9:
						{
						setState(153);
						leftparent();
						}
						break;
					case 10:
						{
						setState(154);
						rightparent();
						}
						break;
					case 11:
						{
						setState(155);
						match(WHITESPACE);
						}
						break;
					}
					}
					break;
				default:
					throw new NoViableAltException(this);
				}
				setState(158); 
				_errHandler.sync(this);
				_alt = getInterpreter().adaptivePredict(_input,13,_ctx);
			} while ( _alt!=2 && _alt!=org.antlr.v4.runtime.atn.ATN.INVALID_ALT_NUMBER );
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class TautologyContext extends ParserRuleContext {
		public List<VariableContext> variable() {
			return getRuleContexts(VariableContext.class);
		}
		public VariableContext variable(int i) {
			return getRuleContext(VariableContext.class,i);
		}
		public EqualsContext equals() {
			return getRuleContext(EqualsContext.class,0);
		}
		public List<TerminalNode> WHITESPACE() { return getTokens(TestParser.WHITESPACE); }
		public TerminalNode WHITESPACE(int i) {
			return getToken(TestParser.WHITESPACE, i);
		}
		public List<DigitContext> digit() {
			return getRuleContexts(DigitContext.class);
		}
		public DigitContext digit(int i) {
			return getRuleContext(DigitContext.class,i);
		}
		public QuotedContext quoted() {
			return getRuleContext(QuotedContext.class,0);
		}
		public TautologyContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_tautology; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).enterTautology(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).exitTautology(this);
		}
	}

	public final TautologyContext tautology() throws RecognitionException {
		TautologyContext _localctx = new TautologyContext(_ctx, getState());
		enterRule(_localctx, 12, RULE_tautology);
		int _la;
		try {
			setState(200);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,22,_ctx) ) {
			case 1:
				enterOuterAlt(_localctx, 1);
				{
				{
				setState(160);
				variable();
				setState(162);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==WHITESPACE) {
					{
					setState(161);
					match(WHITESPACE);
					}
				}

				setState(164);
				equals();
				setState(166);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==WHITESPACE) {
					{
					setState(165);
					match(WHITESPACE);
					}
				}

				setState(168);
				variable();
				}
				}
				break;
			case 2:
				enterOuterAlt(_localctx, 2);
				{
				{
				setState(170);
				digit();
				setState(172);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==WHITESPACE) {
					{
					setState(171);
					match(WHITESPACE);
					}
				}

				setState(174);
				equals();
				setState(176);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==WHITESPACE) {
					{
					setState(175);
					match(WHITESPACE);
					}
				}

				setState(178);
				digit();
				}
				}
				break;
			case 3:
				enterOuterAlt(_localctx, 3);
				{
				{
				setState(180);
				variable();
				setState(182);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==WHITESPACE) {
					{
					setState(181);
					match(WHITESPACE);
					}
				}

				setState(184);
				equals();
				setState(186);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==WHITESPACE) {
					{
					setState(185);
					match(WHITESPACE);
					}
				}

				setState(188);
				digit();
				}
				}
				break;
			case 4:
				enterOuterAlt(_localctx, 4);
				{
				{
				setState(190);
				variable();
				setState(192);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==WHITESPACE) {
					{
					setState(191);
					match(WHITESPACE);
					}
				}

				setState(194);
				equals();
				setState(196);
				_errHandler.sync(this);
				_la = _input.LA(1);
				if (_la==WHITESPACE) {
					{
					setState(195);
					match(WHITESPACE);
					}
				}

				setState(198);
				quoted();
				}
				}
				break;
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class PiggybackContext extends ParserRuleContext {
		public EndqueryContext endquery() {
			return getRuleContext(EndqueryContext.class,0);
		}
		public RequestContext request() {
			return getRuleContext(RequestContext.class,0);
		}
		public QuotesContext quotes() {
			return getRuleContext(QuotesContext.class,0);
		}
		public PiggybackContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_piggyback; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).enterPiggyback(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).exitPiggyback(this);
		}
	}

	public final PiggybackContext piggyback() throws RecognitionException {
		PiggybackContext _localctx = new PiggybackContext(_ctx, getState());
		enterRule(_localctx, 14, RULE_piggyback);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(202);
			endquery();
			setState(203);
			request();
			setState(204);
			quotes();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class StoredprocedureContext extends ParserRuleContext {
		public List<EndqueryContext> endquery() {
			return getRuleContexts(EndqueryContext.class);
		}
		public EndqueryContext endquery(int i) {
			return getRuleContext(EndqueryContext.class,i);
		}
		public ProceduresContext procedures() {
			return getRuleContext(ProceduresContext.class,0);
		}
		public RequestContext request() {
			return getRuleContext(RequestContext.class,0);
		}
		public QuotesContext quotes() {
			return getRuleContext(QuotesContext.class,0);
		}
		public StoredprocedureContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_storedprocedure; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).enterStoredprocedure(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).exitStoredprocedure(this);
		}
	}

	public final StoredprocedureContext storedprocedure() throws RecognitionException {
		StoredprocedureContext _localctx = new StoredprocedureContext(_ctx, getState());
		enterRule(_localctx, 16, RULE_storedprocedure);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(206);
			endquery();
			setState(207);
			procedures();
			setState(208);
			endquery();
			setState(209);
			request();
			setState(210);
			quotes();
			setState(211);
			endquery();
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class CommandContext extends ParserRuleContext {
		public TerminalNode SELECT() { return getToken(TestParser.SELECT, 0); }
		public TerminalNode FROM() { return getToken(TestParser.FROM, 0); }
		public TerminalNode GROUP() { return getToken(TestParser.GROUP, 0); }
		public TerminalNode WHERE() { return getToken(TestParser.WHERE, 0); }
		public TerminalNode HAVING() { return getToken(TestParser.HAVING, 0); }
		public TerminalNode UNION() { return getToken(TestParser.UNION, 0); }
		public CommandContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_command; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).enterCommand(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).exitCommand(this);
		}
	}

	public final CommandContext command() throws RecognitionException {
		CommandContext _localctx = new CommandContext(_ctx, getState());
		enterRule(_localctx, 18, RULE_command);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(213);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << SELECT) | (1L << FROM) | (1L << GROUP) | (1L << WHERE) | (1L << HAVING) | (1L << UNION))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class ProceduresContext extends ParserRuleContext {
		public TerminalNode SHUTDOWN() { return getToken(TestParser.SHUTDOWN, 0); }
		public ProceduresContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_procedures; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).enterProcedures(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).exitProcedures(this);
		}
	}

	public final ProceduresContext procedures() throws RecognitionException {
		ProceduresContext _localctx = new ProceduresContext(_ctx, getState());
		enterRule(_localctx, 20, RULE_procedures);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(215);
			match(SHUTDOWN);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class OperatorContext extends ParserRuleContext {
		public OperatorContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_operator; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).enterOperator(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).exitOperator(this);
		}
	}

	public final OperatorContext operator() throws RecognitionException {
		OperatorContext _localctx = new OperatorContext(_ctx, getState());
		enterRule(_localctx, 22, RULE_operator);
		int _la;
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(217);
			_la = _input.LA(1);
			if ( !((((_la) & ~0x3f) == 0 && ((1L << _la) & ((1L << T__0) | (1L << T__1) | (1L << T__2) | (1L << T__3) | (1L << T__4))) != 0)) ) {
			_errHandler.recoverInline(this);
			}
			else {
				if ( _input.LA(1)==Token.EOF ) matchedEOF = true;
				_errHandler.reportMatch(this);
				consume();
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class QuotesContext extends ParserRuleContext {
		public QuotesContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_quotes; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).enterQuotes(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).exitQuotes(this);
		}
	}

	public final QuotesContext quotes() throws RecognitionException {
		QuotesContext _localctx = new QuotesContext(_ctx, getState());
		enterRule(_localctx, 24, RULE_quotes);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(219);
			match(T__5);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class LeftparentContext extends ParserRuleContext {
		public LeftparentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_leftparent; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).enterLeftparent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).exitLeftparent(this);
		}
	}

	public final LeftparentContext leftparent() throws RecognitionException {
		LeftparentContext _localctx = new LeftparentContext(_ctx, getState());
		enterRule(_localctx, 26, RULE_leftparent);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(221);
			match(T__6);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class RightparentContext extends ParserRuleContext {
		public RightparentContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_rightparent; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).enterRightparent(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).exitRightparent(this);
		}
	}

	public final RightparentContext rightparent() throws RecognitionException {
		RightparentContext _localctx = new RightparentContext(_ctx, getState());
		enterRule(_localctx, 28, RULE_rightparent);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(223);
			match(T__7);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class EqualsContext extends ParserRuleContext {
		public EqualsContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_equals; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).enterEquals(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).exitEquals(this);
		}
	}

	public final EqualsContext equals() throws RecognitionException {
		EqualsContext _localctx = new EqualsContext(_ctx, getState());
		enterRule(_localctx, 30, RULE_equals);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(225);
			match(T__8);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class EndqueryContext extends ParserRuleContext {
		public EndqueryContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_endquery; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).enterEndquery(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).exitEndquery(this);
		}
	}

	public final EndqueryContext endquery() throws RecognitionException {
		EndqueryContext _localctx = new EndqueryContext(_ctx, getState());
		enterRule(_localctx, 32, RULE_endquery);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(227);
			match(T__9);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class DigitContext extends ParserRuleContext {
		public TerminalNode DIGIT() { return getToken(TestParser.DIGIT, 0); }
		public DigitContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_digit; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).enterDigit(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).exitDigit(this);
		}
	}

	public final DigitContext digit() throws RecognitionException {
		DigitContext _localctx = new DigitContext(_ctx, getState());
		enterRule(_localctx, 34, RULE_digit);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(229);
			match(DIGIT);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class VariableContext extends ParserRuleContext {
		public TerminalNode WORD() { return getToken(TestParser.WORD, 0); }
		public VariableContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_variable; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).enterVariable(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).exitVariable(this);
		}
	}

	public final VariableContext variable() throws RecognitionException {
		VariableContext _localctx = new VariableContext(_ctx, getState());
		enterRule(_localctx, 36, RULE_variable);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(231);
			match(WORD);
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static class QuotedContext extends ParserRuleContext {
		public TerminalNode WORD() { return getToken(TestParser.WORD, 0); }
		public TerminalNode DIGIT() { return getToken(TestParser.DIGIT, 0); }
		public QuotedContext(ParserRuleContext parent, int invokingState) {
			super(parent, invokingState);
		}
		@Override public int getRuleIndex() { return RULE_quoted; }
		@Override
		public void enterRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).enterQuoted(this);
		}
		@Override
		public void exitRule(ParseTreeListener listener) {
			if ( listener instanceof TestListener ) ((TestListener)listener).exitQuoted(this);
		}
	}

	public final QuotedContext quoted() throws RecognitionException {
		QuotedContext _localctx = new QuotedContext(_ctx, getState());
		enterRule(_localctx, 38, RULE_quoted);
		try {
			enterOuterAlt(_localctx, 1);
			{
			setState(241);
			_errHandler.sync(this);
			switch ( getInterpreter().adaptivePredict(_input,23,_ctx) ) {
			case 1:
				{
				setState(233);
				match(T__5);
				setState(234);
				match(WORD);
				setState(235);
				match(T__5);
				}
				break;
			case 2:
				{
				setState(236);
				match(T__5);
				setState(237);
				match(DIGIT);
				setState(238);
				match(T__5);
				}
				break;
			case 3:
				{
				setState(239);
				match(T__5);
				setState(240);
				match(T__5);
				}
				break;
			}
			}
		}
		catch (RecognitionException re) {
			_localctx.exception = re;
			_errHandler.reportError(this, re);
			_errHandler.recover(this, re);
		}
		finally {
			exitRule();
		}
		return _localctx;
	}

	public static final String _serializedATN =
		"\3\u608b\ua72a\u8133\ub9ed\u417c\u3be7\u7786\u5964\3\27\u00f6\4\2\t\2"+
		"\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13"+
		"\t\13\4\f\t\f\4\r\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22"+
		"\4\23\t\23\4\24\t\24\4\25\t\25\3\2\6\2,\n\2\r\2\16\2-\3\2\3\2\3\3\3\3"+
		"\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3"+
		"\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\3\5\3N\n\3\3\3\5\3Q\n\3\3\4\3\4\3\4\3"+
		"\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\5\4b\n\4\3\4\5\4e\n\4\3"+
		"\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\3\4\5\4r\n\4\3\4\3\4\3\4\3\4\3"+
		"\4\3\4\5\4z\n\4\3\4\5\4}\n\4\5\4\177\n\4\3\5\3\5\3\5\3\5\3\5\3\5\3\5\3"+
		"\5\3\5\5\5\u008a\n\5\3\5\5\5\u008d\n\5\3\6\3\6\3\6\5\6\u0092\n\6\3\7\3"+
		"\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\3\7\6\7\u009f\n\7\r\7\16\7\u00a0\3"+
		"\b\3\b\5\b\u00a5\n\b\3\b\3\b\5\b\u00a9\n\b\3\b\3\b\3\b\3\b\5\b\u00af\n"+
		"\b\3\b\3\b\5\b\u00b3\n\b\3\b\3\b\3\b\3\b\5\b\u00b9\n\b\3\b\3\b\5\b\u00bd"+
		"\n\b\3\b\3\b\3\b\3\b\5\b\u00c3\n\b\3\b\3\b\5\b\u00c7\n\b\3\b\3\b\5\b\u00cb"+
		"\n\b\3\t\3\t\3\t\3\t\3\n\3\n\3\n\3\n\3\n\3\n\3\n\3\13\3\13\3\f\3\f\3\r"+
		"\3\r\3\16\3\16\3\17\3\17\3\20\3\20\3\21\3\21\3\22\3\22\3\23\3\23\3\24"+
		"\3\24\3\25\3\25\3\25\3\25\3\25\3\25\3\25\3\25\5\25\u00f4\n\25\3\25\2\2"+
		"\26\2\4\6\b\n\f\16\20\22\24\26\30\32\34\36 \"$&(\2\4\3\2\r\22\3\2\3\7"+
		"\2\u0106\2+\3\2\2\2\4\61\3\2\2\2\6~\3\2\2\2\b\u0080\3\2\2\2\n\u0091\3"+
		"\2\2\2\f\u009e\3\2\2\2\16\u00ca\3\2\2\2\20\u00cc\3\2\2\2\22\u00d0\3\2"+
		"\2\2\24\u00d7\3\2\2\2\26\u00d9\3\2\2\2\30\u00db\3\2\2\2\32\u00dd\3\2\2"+
		"\2\34\u00df\3\2\2\2\36\u00e1\3\2\2\2 \u00e3\3\2\2\2\"\u00e5\3\2\2\2$\u00e7"+
		"\3\2\2\2&\u00e9\3\2\2\2(\u00f3\3\2\2\2*,\5\n\6\2+*\3\2\2\2,-\3\2\2\2-"+
		"+\3\2\2\2-.\3\2\2\2./\3\2\2\2/\60\7\2\2\3\60\3\3\2\2\2\61\62\5\24\13\2"+
		"\62\63\5\f\7\2\63\64\7\27\2\2\64\65\5\24\13\2\65\66\5\f\7\2\66\67\7\27"+
		"\2\2\678\5\24\13\289\5\f\7\29:\5 \21\2:;\7\26\2\2;<\5\34\17\2<=\5\24\13"+
		"\2=>\5\f\7\2>?\7\27\2\2?@\5\24\13\2@A\5\f\7\2AB\7\27\2\2BC\5\24\13\2C"+
		"D\5\f\7\2DE\5 \21\2EF\7\26\2\2FG\5\34\17\2GH\5\24\13\2HI\5\f\7\2IJ\7\27"+
		"\2\2JK\5\24\13\2KM\5\f\7\2LN\7\27\2\2ML\3\2\2\2MN\3\2\2\2NP\3\2\2\2OQ"+
		"\7\27\2\2PO\3\2\2\2PQ\3\2\2\2Q\5\3\2\2\2RS\5\24\13\2ST\5\f\7\2TU\7\27"+
		"\2\2UV\5\24\13\2VW\5\f\7\2WX\7\27\2\2XY\5\24\13\2YZ\5\f\7\2Z[\7\27\2\2"+
		"[\\\5\24\13\2\\]\5\f\7\2]^\7\27\2\2^_\5\24\13\2_a\5\f\7\2`b\7\27\2\2a"+
		"`\3\2\2\2ab\3\2\2\2bd\3\2\2\2ce\7\27\2\2dc\3\2\2\2de\3\2\2\2e\177\3\2"+
		"\2\2fg\5\24\13\2gh\5\f\7\2hi\7\27\2\2ij\5\24\13\2jk\5\f\7\2kl\7\27\2\2"+
		"lm\5\24\13\2mn\5\f\7\2no\7\27\2\2oq\5\24\13\2pr\5\f\7\2qp\3\2\2\2qr\3"+
		"\2\2\2rs\3\2\2\2st\5\24\13\2tu\5\f\7\2uv\7\27\2\2vw\5\24\13\2wy\5\f\7"+
		"\2xz\7\27\2\2yx\3\2\2\2yz\3\2\2\2z|\3\2\2\2{}\7\27\2\2|{\3\2\2\2|}\3\2"+
		"\2\2}\177\3\2\2\2~R\3\2\2\2~f\3\2\2\2\177\7\3\2\2\2\u0080\u0081\5\24\13"+
		"\2\u0081\u0082\5\f\7\2\u0082\u0083\7\27\2\2\u0083\u0084\5\24\13\2\u0084"+
		"\u0085\5\f\7\2\u0085\u0086\7\27\2\2\u0086\u0087\5\24\13\2\u0087\u0089"+
		"\5\f\7\2\u0088\u008a\7\27\2\2\u0089\u0088\3\2\2\2\u0089\u008a\3\2\2\2"+
		"\u008a\u008c\3\2\2\2\u008b\u008d\7\27\2\2\u008c\u008b\3\2\2\2\u008c\u008d"+
		"\3\2\2\2\u008d\t\3\2\2\2\u008e\u0092\5\b\5\2\u008f\u0092\5\4\3\2\u0090"+
		"\u0092\5\6\4\2\u0091\u008e\3\2\2\2\u0091\u008f\3\2\2\2\u0091\u0090\3\2"+
		"\2\2\u0092\13\3\2\2\2\u0093\u009f\5\30\r\2\u0094\u009f\5\32\16\2\u0095"+
		"\u009f\5&\24\2\u0096\u009f\5$\23\2\u0097\u009f\5\16\b\2\u0098\u009f\5"+
		"\20\t\2\u0099\u009f\5\22\n\2\u009a\u009f\5\"\22\2\u009b\u009f\5\34\17"+
		"\2\u009c\u009f\5\36\20\2\u009d\u009f\7\26\2\2\u009e\u0093\3\2\2\2\u009e"+
		"\u0094\3\2\2\2\u009e\u0095\3\2\2\2\u009e\u0096\3\2\2\2\u009e\u0097\3\2"+
		"\2\2\u009e\u0098\3\2\2\2\u009e\u0099\3\2\2\2\u009e\u009a\3\2\2\2\u009e"+
		"\u009b\3\2\2\2\u009e\u009c\3\2\2\2\u009e\u009d\3\2\2\2\u009f\u00a0\3\2"+
		"\2\2\u00a0\u009e\3\2\2\2\u00a0\u00a1\3\2\2\2\u00a1\r\3\2\2\2\u00a2\u00a4"+
		"\5&\24\2\u00a3\u00a5\7\26\2\2\u00a4\u00a3\3\2\2\2\u00a4\u00a5\3\2\2\2"+
		"\u00a5\u00a6\3\2\2\2\u00a6\u00a8\5 \21\2\u00a7\u00a9\7\26\2\2\u00a8\u00a7"+
		"\3\2\2\2\u00a8\u00a9\3\2\2\2\u00a9\u00aa\3\2\2\2\u00aa\u00ab\5&\24\2\u00ab"+
		"\u00cb\3\2\2\2\u00ac\u00ae\5$\23\2\u00ad\u00af\7\26\2\2\u00ae\u00ad\3"+
		"\2\2\2\u00ae\u00af\3\2\2\2\u00af\u00b0\3\2\2\2\u00b0\u00b2\5 \21\2\u00b1"+
		"\u00b3\7\26\2\2\u00b2\u00b1\3\2\2\2\u00b2\u00b3\3\2\2\2\u00b3\u00b4\3"+
		"\2\2\2\u00b4\u00b5\5$\23\2\u00b5\u00cb\3\2\2\2\u00b6\u00b8\5&\24\2\u00b7"+
		"\u00b9\7\26\2\2\u00b8\u00b7\3\2\2\2\u00b8\u00b9\3\2\2\2\u00b9\u00ba\3"+
		"\2\2\2\u00ba\u00bc\5 \21\2\u00bb\u00bd\7\26\2\2\u00bc\u00bb\3\2\2\2\u00bc"+
		"\u00bd\3\2\2\2\u00bd\u00be\3\2\2\2\u00be\u00bf\5$\23\2\u00bf\u00cb\3\2"+
		"\2\2\u00c0\u00c2\5&\24\2\u00c1\u00c3\7\26\2\2\u00c2\u00c1\3\2\2\2\u00c2"+
		"\u00c3\3\2\2\2\u00c3\u00c4\3\2\2\2\u00c4\u00c6\5 \21\2\u00c5\u00c7\7\26"+
		"\2\2\u00c6\u00c5\3\2\2\2\u00c6\u00c7\3\2\2\2\u00c7\u00c8\3\2\2\2\u00c8"+
		"\u00c9\5(\25\2\u00c9\u00cb\3\2\2\2\u00ca\u00a2\3\2\2\2\u00ca\u00ac\3\2"+
		"\2\2\u00ca\u00b6\3\2\2\2\u00ca\u00c0\3\2\2\2\u00cb\17\3\2\2\2\u00cc\u00cd"+
		"\5\"\22\2\u00cd\u00ce\5\f\7\2\u00ce\u00cf\5\32\16\2\u00cf\21\3\2\2\2\u00d0"+
		"\u00d1\5\"\22\2\u00d1\u00d2\5\26\f\2\u00d2\u00d3\5\"\22\2\u00d3\u00d4"+
		"\5\f\7\2\u00d4\u00d5\5\32\16\2\u00d5\u00d6\5\"\22\2\u00d6\23\3\2\2\2\u00d7"+
		"\u00d8\t\2\2\2\u00d8\25\3\2\2\2\u00d9\u00da\7\23\2\2\u00da\27\3\2\2\2"+
		"\u00db\u00dc\t\3\2\2\u00dc\31\3\2\2\2\u00dd\u00de\7\b\2\2\u00de\33\3\2"+
		"\2\2\u00df\u00e0\7\t\2\2\u00e0\35\3\2\2\2\u00e1\u00e2\7\n\2\2\u00e2\37"+
		"\3\2\2\2\u00e3\u00e4\7\13\2\2\u00e4!\3\2\2\2\u00e5\u00e6\7\f\2\2\u00e6"+
		"#\3\2\2\2\u00e7\u00e8\7\25\2\2\u00e8%\3\2\2\2\u00e9\u00ea\7\24\2\2\u00ea"+
		"\'\3\2\2\2\u00eb\u00ec\7\b\2\2\u00ec\u00ed\7\24\2\2\u00ed\u00f4\7\b\2"+
		"\2\u00ee\u00ef\7\b\2\2\u00ef\u00f0\7\25\2\2\u00f0\u00f4\7\b\2\2\u00f1"+
		"\u00f2\7\b\2\2\u00f2\u00f4\7\b\2\2\u00f3\u00eb\3\2\2\2\u00f3\u00ee\3\2"+
		"\2\2\u00f3\u00f1\3\2\2\2\u00f4)\3\2\2\2\32-MPadqy|~\u0089\u008c\u0091"+
		"\u009e\u00a0\u00a4\u00a8\u00ae\u00b2\u00b8\u00bc\u00c2\u00c6\u00ca\u00f3";
	public static final ATN _ATN =
		new ATNDeserializer().deserialize(_serializedATN.toCharArray());
	static {
		_decisionToDFA = new DFA[_ATN.getNumberOfDecisions()];
		for (int i = 0; i < _ATN.getNumberOfDecisions(); i++) {
			_decisionToDFA[i] = new DFA(_ATN.getDecisionState(i), i);
		}
	}
}
