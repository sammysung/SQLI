---
layout: single
title: Acknowledgments
permalink: /ack/
---
## Resources
- "All about SQL injection attacks" paper provided by Dr. Subburaj.
- Github for code and website hosting.

## Thanks
- [Github](https://github.com/)
- [Minimal Mistakes](https://github.com/mmistakes/minimal-mistakes) for theming.
