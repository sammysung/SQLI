// Generated from Test.g4 by ANTLR 4.7.2
package com.sqli.framework;
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link TestParser}.
 */
public interface TestListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link TestParser#query}.
	 * @param ctx the parse tree
	 */
	void enterQuery(TestParser.QueryContext ctx);
	/**
	 * Exit a parse tree produced by {@link TestParser#query}.
	 * @param ctx the parse tree
	 */
	void exitQuery(TestParser.QueryContext ctx);
	/**
	 * Enter a parse tree produced by {@link TestParser#doublenested}.
	 * @param ctx the parse tree
	 */
	void enterDoublenested(TestParser.DoublenestedContext ctx);
	/**
	 * Exit a parse tree produced by {@link TestParser#doublenested}.
	 * @param ctx the parse tree
	 */
	void exitDoublenested(TestParser.DoublenestedContext ctx);
	/**
	 * Enter a parse tree produced by {@link TestParser#longline}.
	 * @param ctx the parse tree
	 */
	void enterLongline(TestParser.LonglineContext ctx);
	/**
	 * Exit a parse tree produced by {@link TestParser#longline}.
	 * @param ctx the parse tree
	 */
	void exitLongline(TestParser.LonglineContext ctx);
	/**
	 * Enter a parse tree produced by {@link TestParser#line}.
	 * @param ctx the parse tree
	 */
	void enterLine(TestParser.LineContext ctx);
	/**
	 * Exit a parse tree produced by {@link TestParser#line}.
	 * @param ctx the parse tree
	 */
	void exitLine(TestParser.LineContext ctx);
	/**
	 * Enter a parse tree produced by {@link TestParser#linetype}.
	 * @param ctx the parse tree
	 */
	void enterLinetype(TestParser.LinetypeContext ctx);
	/**
	 * Exit a parse tree produced by {@link TestParser#linetype}.
	 * @param ctx the parse tree
	 */
	void exitLinetype(TestParser.LinetypeContext ctx);
	/**
	 * Enter a parse tree produced by {@link TestParser#request}.
	 * @param ctx the parse tree
	 */
	void enterRequest(TestParser.RequestContext ctx);
	/**
	 * Exit a parse tree produced by {@link TestParser#request}.
	 * @param ctx the parse tree
	 */
	void exitRequest(TestParser.RequestContext ctx);
	/**
	 * Enter a parse tree produced by {@link TestParser#tautology}.
	 * @param ctx the parse tree
	 */
	void enterTautology(TestParser.TautologyContext ctx);
	/**
	 * Exit a parse tree produced by {@link TestParser#tautology}.
	 * @param ctx the parse tree
	 */
	void exitTautology(TestParser.TautologyContext ctx);
	/**
	 * Enter a parse tree produced by {@link TestParser#piggyback}.
	 * @param ctx the parse tree
	 */
	void enterPiggyback(TestParser.PiggybackContext ctx);
	/**
	 * Exit a parse tree produced by {@link TestParser#piggyback}.
	 * @param ctx the parse tree
	 */
	void exitPiggyback(TestParser.PiggybackContext ctx);
	/**
	 * Enter a parse tree produced by {@link TestParser#storedprocedure}.
	 * @param ctx the parse tree
	 */
	void enterStoredprocedure(TestParser.StoredprocedureContext ctx);
	/**
	 * Exit a parse tree produced by {@link TestParser#storedprocedure}.
	 * @param ctx the parse tree
	 */
	void exitStoredprocedure(TestParser.StoredprocedureContext ctx);
	/**
	 * Enter a parse tree produced by {@link TestParser#command}.
	 * @param ctx the parse tree
	 */
	void enterCommand(TestParser.CommandContext ctx);
	/**
	 * Exit a parse tree produced by {@link TestParser#command}.
	 * @param ctx the parse tree
	 */
	void exitCommand(TestParser.CommandContext ctx);
	/**
	 * Enter a parse tree produced by {@link TestParser#procedures}.
	 * @param ctx the parse tree
	 */
	void enterProcedures(TestParser.ProceduresContext ctx);
	/**
	 * Exit a parse tree produced by {@link TestParser#procedures}.
	 * @param ctx the parse tree
	 */
	void exitProcedures(TestParser.ProceduresContext ctx);
	/**
	 * Enter a parse tree produced by {@link TestParser#operator}.
	 * @param ctx the parse tree
	 */
	void enterOperator(TestParser.OperatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link TestParser#operator}.
	 * @param ctx the parse tree
	 */
	void exitOperator(TestParser.OperatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link TestParser#quotes}.
	 * @param ctx the parse tree
	 */
	void enterQuotes(TestParser.QuotesContext ctx);
	/**
	 * Exit a parse tree produced by {@link TestParser#quotes}.
	 * @param ctx the parse tree
	 */
	void exitQuotes(TestParser.QuotesContext ctx);
	/**
	 * Enter a parse tree produced by {@link TestParser#leftparent}.
	 * @param ctx the parse tree
	 */
	void enterLeftparent(TestParser.LeftparentContext ctx);
	/**
	 * Exit a parse tree produced by {@link TestParser#leftparent}.
	 * @param ctx the parse tree
	 */
	void exitLeftparent(TestParser.LeftparentContext ctx);
	/**
	 * Enter a parse tree produced by {@link TestParser#rightparent}.
	 * @param ctx the parse tree
	 */
	void enterRightparent(TestParser.RightparentContext ctx);
	/**
	 * Exit a parse tree produced by {@link TestParser#rightparent}.
	 * @param ctx the parse tree
	 */
	void exitRightparent(TestParser.RightparentContext ctx);
	/**
	 * Enter a parse tree produced by {@link TestParser#equals}.
	 * @param ctx the parse tree
	 */
	void enterEquals(TestParser.EqualsContext ctx);
	/**
	 * Exit a parse tree produced by {@link TestParser#equals}.
	 * @param ctx the parse tree
	 */
	void exitEquals(TestParser.EqualsContext ctx);
	/**
	 * Enter a parse tree produced by {@link TestParser#endquery}.
	 * @param ctx the parse tree
	 */
	void enterEndquery(TestParser.EndqueryContext ctx);
	/**
	 * Exit a parse tree produced by {@link TestParser#endquery}.
	 * @param ctx the parse tree
	 */
	void exitEndquery(TestParser.EndqueryContext ctx);
	/**
	 * Enter a parse tree produced by {@link TestParser#digit}.
	 * @param ctx the parse tree
	 */
	void enterDigit(TestParser.DigitContext ctx);
	/**
	 * Exit a parse tree produced by {@link TestParser#digit}.
	 * @param ctx the parse tree
	 */
	void exitDigit(TestParser.DigitContext ctx);
	/**
	 * Enter a parse tree produced by {@link TestParser#variable}.
	 * @param ctx the parse tree
	 */
	void enterVariable(TestParser.VariableContext ctx);
	/**
	 * Exit a parse tree produced by {@link TestParser#variable}.
	 * @param ctx the parse tree
	 */
	void exitVariable(TestParser.VariableContext ctx);
	/**
	 * Enter a parse tree produced by {@link TestParser#quoted}.
	 * @param ctx the parse tree
	 */
	void enterQuoted(TestParser.QuotedContext ctx);
	/**
	 * Exit a parse tree produced by {@link TestParser#quoted}.
	 * @param ctx the parse tree
	 */
	void exitQuoted(TestParser.QuotedContext ctx);
}
