---
layout: single
title: Purpose
permalink: /purpose/
---

# SQL Injection Framework Project 2018-2019

This project aims to create a framework for various SQL Injection attack tests, as well as implement the tests 
themselves and generate meaningful reports. 

This work is being built off of the foundation of a research paper currently in the publication process by WT students and faculity.
