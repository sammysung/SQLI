#!/bin/bash

sudo apt-get install build-essential patch ruby-dev zlib1g-dev liblzma-dev ruby-all-dev default-jre
