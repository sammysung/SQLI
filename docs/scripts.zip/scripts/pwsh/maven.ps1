
cd ..
cd ..
mvn clean compile package