cd ..
cmake .. -G "Eclipse CDT4 - Unix Makefiles" -B ../E-Unix