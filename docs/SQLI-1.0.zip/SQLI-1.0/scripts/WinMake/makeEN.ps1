cd ..
cmake .. -G "Eclipse CDT4 - NMake Makefiles" -B ../E-NMake
