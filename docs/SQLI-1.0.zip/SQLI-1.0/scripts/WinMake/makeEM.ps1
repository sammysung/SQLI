cd ..
cd ..
cmake . -S . -G "Eclipse CDT4 - MinGW Makefiles" -B ./E-Min
