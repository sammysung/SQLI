cd ..
cmake .. -G "NMake Makefiles" -B ../nmake