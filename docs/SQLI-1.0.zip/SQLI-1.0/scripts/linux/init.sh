#! /bin/bash
cd ..
cd ..
javac *.java
java frame -hq
