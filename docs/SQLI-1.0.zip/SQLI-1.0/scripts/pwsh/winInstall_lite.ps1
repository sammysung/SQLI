choco install jdk11 -y
choco install intellijidea-community -y
#choco install cmake --installargs 'ADD_CMAKE_TO_PATH=System' -y
choco install mingw -y
choco install maven -y
refreshenv
