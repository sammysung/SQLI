#!/usr/bin/env bash

mvn clean compile package exec:java