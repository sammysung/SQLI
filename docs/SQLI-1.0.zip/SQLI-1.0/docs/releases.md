---
layout: single
title: Releases
permalink: /releases/
---
# Most current release (V1.0):

[SQLI-1.0](/SQLI-1.0.zip)

# Older releases:

[SQLI-0.1.1](/SQLI-0.1.1-alpha.zip)

[SQLI-0.1.0](/SQLI-0.1.0-alpha.zip)

