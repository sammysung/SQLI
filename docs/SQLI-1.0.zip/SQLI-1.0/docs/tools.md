---
layout: single
title: Tools Used
permalink: /tools/
--- 
# List of tools used for development

- [Java](https://www.oracle.com/java/)
- [Ruby](https://www.ruby-lang.org/en/)
- [CMake](https://cmake.org/)
- [Bash Shell Scripting](https://www.gnu.org/software/bash/)
- [Jekyll](https://jekyllrb.com/)
- [Github Hosting](https://pages.github.com/)
- [Apache Maven](https://maven.apache.org/)
- [Intellij](https://www.jetbrains.com/idea/)
- [Apache Ant](https://ant.apache.org/)
