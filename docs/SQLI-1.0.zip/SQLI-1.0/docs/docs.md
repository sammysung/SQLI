---
layout: single
title: Standalone Documents
permalink: /docs/
--- 
# These links will open in your browser by default, for quick viewing.
# Right-click on the below links in order to download these files:

Phase one is outdated, but contains info on the setup script structure and help for CMake, should that build environment be deemed useful.

[Phase 1 Readme](/PleaseRead!.txt)

[Main Page Readme](/instr.md)
