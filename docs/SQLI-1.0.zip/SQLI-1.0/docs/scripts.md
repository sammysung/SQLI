---
layout: single
title: Sample Queries
permalink: /scripts/
---
# Download the files here!

[Master Script Folder](/scripts.zip)

[Linux Operation Scripts](/linux.zip)

[Linux CMake Scripts](/Make.zip)

[Powershell Operation Scripts](/pwsh.zip)

[Windows CMD Operation Scripts](/WinSetup.zip)

[Windows Powershell/CMD CMake Scripts](/WinMake.zip)

[OSX Scripts](/osx.zip)
