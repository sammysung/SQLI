---
layout: single
title: Purpose
permalink: /purpose/
---

# SQL Injection Framework Project 2018-2019

This project aims to create a framework for various SQL Injection attack tests, as well as implement the tests themselves and generate meaningful reports. 

The current progress of this project includes a working ANTLR4 implementation, combined with custom code to facilitate the command line options for operation and to process the information provided from the ANTLR4 grammar we have created into seperate report files.

This work is being built off of the foundation of a research paper currently in the publication process by WT students and faculity.
