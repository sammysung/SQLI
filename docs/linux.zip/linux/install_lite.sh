#!/bin/bash

sudo apt-get install default-jre maven #cmake
sudo snap install intellij-idea-community --classic
