#!/bin/bash

sudo apt-get install build-essential patch ruby-dev zlib1g-dev liblzma-dev ruby-all-dev default-jre snapd cmake maven
sudo snap install intellij-idea-community --classic
sudo snap install powershell --classic
sudo snap install vscode --classic
