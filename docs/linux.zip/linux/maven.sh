#!/usr/bin/env bash

cd ..
cd ..
mvn clean compile package exec:java
