choco install jdk11 -y
choco install cmake --installargs 'ADD_CMAKE_TO_PATH=System' -y
choco install mingw -y
refreshenv