
cd ..
cd ..
mvn clean compile package exec:java