#! /bin/bash
javac *.java
java frame -hq
